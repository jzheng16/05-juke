const AUDIO = document.createElement('audio');
export default AUDIO;
