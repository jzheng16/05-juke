describe('the unique-through plugin', function() {
  require('./unique-through')
})
