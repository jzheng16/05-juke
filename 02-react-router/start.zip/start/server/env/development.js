module.exports = {
  DATABASE_URI: 'postgres://localhost:5432/juke'
};
